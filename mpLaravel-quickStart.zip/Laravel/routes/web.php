<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/', function () {
    return view('welcome');
});

Route::get('soap', function () {

	try{

	    $sms = Melipayamak::sms('soap');
	    $to = '09123456789';
	    $from = '5000...';
	    $text = 'تست وب سرویس ملی پیامک';
	    $response = $sms->send($to,$from,$text);
	    echo $response; //RecId or Error Number 
	}catch(Exception $e){
	    echo $e->getMessage();
	}

    return view('welcome');
});

Route::get('rest', function () {

	try{

	    $sms = Melipayamak::sms();
	    $to = '09123456789';
	    $from = '5000...';
	    $text = 'تست وب سرویس ملی پیامک';
	    $response = $sms->send($to, $from, $text);
	    $json = json_decode($response);
	    echo $json->Value; //RecId or Error Number 
	}catch(Exception $e){
	    echo $e->getMessage();
	}

    return view('welcome');
});




Route::get('add', function () {

	try{

	    $users = Melipayamak::users();

	    // Set request params
		$params = array('text' => 'bad');
		$test = "bad";		

	    $response = $users->add((object)$test);
	    echo $response;
	}catch(Exception $e){
	    echo $e->getMessage();
	}

    return view('welcome');
});